import QQAdapter from './adapter';

export default QQAdapter;
